--Creo un Database con nome Happiness

CREATE DATABASE Happiness;

--Creo un nuovo utente

USE Happiness;
CREATE LOGIN MDG WITH PASSWORD = 'password';
CREATE USER MDG FOR LOGIN MDG;

GRANT SELECT, INSERT, UPDATE, DELETE ON Nations TO MDG;
GRANT SELECT, INSERT, UPDATE, DELETE ON Happiness TO MDG;
GRANT SELECT, INSERT, UPDATE, DELETE ON Poverty TO MDG;
GRANT SELECT, INSERT, UPDATE, DELETE ON LifeExpectancy TO MDG;

--Creo le tabelle

CREATE TABLE Nations (
	StateTerritory VARCHAR(10),
	Area VARCHAR(100),
	Continent VARCHAR(100),
	Country VARCHAR(100),
	CodISOalpha2 VARCHAR (10),
	CodISOalpha3 VARCHAR(10),
	CONSTRAINT PK_Nations PRIMARY KEY(Country))

CREATE TABLE Happiness (
	Indice INT IDENTITY(0, 1),
	Country VARCHAR(100),
	Anno INT,
	LifeLadder DECIMAL(18,10),
	LogGDPperCapita DECIMAL(18,10),
	SocialSupport DECIMAL(18,10),
	HealthyLifeExpectancy DECIMAL(18,10),
	FreedomOfChoise DECIMAL(18,10),
	Generosity DECIMAL(18,10),
	PerceptionOfCorruption DECIMAL(18,10),
	PositiveAffect DECIMAL(18,10),
	NegativeAffect DECIMAL(18,10),
	CONSTRAINT PK_Happiness PRIMARY KEY(Indice),
	CONSTRAINT FK_Nations_Happiness FOREIGN KEY (Country) REFERENCES Nations(Country)
	) 

CREATE TABLE LifeExpectancy (
	Indice INT IDENTITY(0,1),
	CountryCode VARCHAR(5),
	Country VARCHAR(100),
	Anno INT,
	LifeExpectancy DECIMAL(10,6),
	CONSTRAINT PK_LifeExpectancy PRIMARY KEY(Indice),
	CONSTRAINT FK_Nations_LifeExpectancy FOREIGN KEY (Country) REFERENCES Nations(Country)
	)

CREATE TABLE Poverty(
	Indice INT IDENTITY(0,1), 
	Country VARCHAR(100),
	Anno INT,
	reporting_level VARCHAR(25),
	welfare_type VARCHAR(25),
	ppp_version INT,
	headcount_ratio_international_povline DECIMAL(10, 8),
	headcount_ratio_lower_mid_income_povline DECIMAL(10, 8),
	headcount_ratio_upper_mid_income_povline DECIMAL(10, 8),
	headcount_international_povline FLOAT,
	headcount_lower_mid_income_povline FLOAT,
	headcount_upper_mid_income_povline FLOAT,
	decile1_avg DECIMAL(15, 8),
	decile2_avg DECIMAL(15, 8),
	decile3_avg DECIMAL(15, 8),
	decile4_avg DECIMAL(15, 8),
	decile5_avg DECIMAL(15, 8),
	decile6_avg DECIMAL(15, 8),
	decile7_avg DECIMAL(15, 8),
	decile8_avg DECIMAL(15, 8),
	decile9_avg DECIMAL(15, 8),
	decile10_avg DECIMAL(15, 8),
	gini DECIMAL(10, 8),
	CONSTRAINT PK_Poverty PRIMARY KEY(Indice),
	CONSTRAINT FK_Nations_Poverty FOREIGN KEY (Country) REFERENCES Nations(Country)
	)

--verifico che l'inserimento sia andato a buon fine

SELECT *
FROM Nations

SELECT *
FROM LifeExpectancy

SELECT *
FROM Happiness

SELECT *
FROM Poverty